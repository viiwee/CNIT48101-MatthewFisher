When working with the Crypto library, install vs_buildtools and select the C++ package within it. No need to install all
    of Visual Studio
